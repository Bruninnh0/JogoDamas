const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

app.use(express.static(path.join(__dirname, 'public')));

// Lista de jogadores conectados
let players = [];

wss.on('connection', function connection(ws) {
    if (players.length >= 2) {
        ws.send(JSON.stringify({ type: 'error', message: 'Jogo cheio' }));
        ws.close();
        return;
    }

    players.push(ws);
    const playerId = players.indexOf(ws) + 1;
    ws.send(`init ${playerId}\n`);


ws.on('message', function incoming(message) {
    console.log("Mensagem recebida:", message.toString());

    // Reenvia para todos os outros clientes
    wss.clients.forEach(client => {
        if (client !== ws && client.readyState === WebSocket.OPEN) {
            client.send(message.toString()); // texto puro
        }
    });
});


    ws.on('close', () => {
        players = players.filter(p => p !== ws);
    });
});

const PORT = 3000;
server.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});
